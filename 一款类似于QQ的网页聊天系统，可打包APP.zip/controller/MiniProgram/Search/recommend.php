<?php
/**
 * Created by PhpStorm.
 * User: zhangjun
 * Date: 13/11/2018
 * Time: 10:57 AM
 */

return array(
    "groupIds" => array(
        "u5sdxyegkc",
        "h9txas5zrr",
        "20xbmsqytw",
        "bpbu8xt0cb"
    ),
    'miniProgramId'    => "200",
    "about_us_desc"    => "欢迎加入核武交流协作大家庭，！本平台致力于打造最安全的警务工作交流协作，服务器专门搭建，内容私密，阅后即焚，安全无过滤，请大家珍惜使用！平台初建，功能不断完善中……",
    "about_us_title"   => "警界核武器创研小组",
    "about_us_contact" => "微信号：zwtand911"
);